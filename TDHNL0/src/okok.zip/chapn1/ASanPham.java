package chapn1;

public abstract class ASanPham implements ISanPham {
	protected KichThuoc kichthuoc;
	protected String loaiGo;
	protected double donGia;
	/**
	 * @param kichthuoc
	 * @param loaiGo
	 * @param donGia
	 */
	public ASanPham(KichThuoc kichthuoc, String loaiGo, double donGia) {
		this.kichthuoc = kichthuoc;
		this.loaiGo = loaiGo;
		this.donGia = donGia;
	}
	@Override
	public double getDonGia() {
		// TODO Auto-generated method stub
		return this.donGia;
	}
	
	
}
