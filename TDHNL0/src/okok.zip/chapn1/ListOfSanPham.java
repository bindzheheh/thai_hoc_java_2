package chapn1;

public interface ListOfSanPham {
	public ListOfSanPham getDanhSachBan();

}
